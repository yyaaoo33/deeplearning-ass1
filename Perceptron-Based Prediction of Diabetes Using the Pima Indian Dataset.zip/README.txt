
To make a sample CVPR paper, copy the contents of this directory
somewhere, and type

 latex egpaper_final

or 

 pdflatex egpaper_final


To make a copy with the review style (for anonymous review, and
including line numbers, replace "egpaper_final" with
"egpaper_for_review" in the commands above.

Note that in some environments, it may be necessary to run bibtex explicitly (bibtex egpaper_final).
